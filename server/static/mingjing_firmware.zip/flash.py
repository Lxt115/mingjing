"""
明镜固件烧录脚本 (ESP32-C3)
============================

用法:
    python flash.py                  # 自动检测串口并烧录
    python flash.py COM3             # 指定串口号
    python flash.py --list           # 列出可用串口

首次使用前安装依赖:
    pip install esptool

烧录完成后设备会自动重启进入正常模式。
首次启动会进入 AP 配网模式 (SSID: Aidoll-Config)。
"""

import sys
import os
import subprocess
import argparse
import time

# ── 烧录配置 ──
CHIP = "esp32c3"
BAUD = 921600

# bin 文件路径（与本脚本同目录的 build/ 下）
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BUILD_DIR = os.path.join(SCRIPT_DIR, "build")

FLASH_MAP = [
    # (offset,  file,                          description)
    ("0x0",     "bootloader/bootloader.bin",     "Bootloader"),
    ("0x8000",  "partition_table/partition-table.bin", "Partition Table"),
    ("0xe000",  "ota_data_initial.bin",           "OTA Data"),
    ("0x20000", "aidoll_device.bin",              "Firmware"),
]

# ── 串口检测 ──


def list_serial_ports():
    """列出可用串口，返回 [(port, description), ...]"""
    try:
        import serial.tools.list_ports
        ports = serial.tools.list_ports.comports()
        return [(p.device, p.description) for p in sorted(ports)]
    except ImportError:
        print("[!] pyserial not installed. Run: pip install pyserial")
        return []


def detect_esp_port():
    """自动检测 ESP32 设备的串口"""
    ports = list_serial_ports()
    if not ports:
        return None

    # 优先匹配 ESP / CP210x / CH340 / USB Serial
    esp_keywords = ["cp210", "ch340", "esp32", "usb serial", "silicon labs",
                    "wch", "ftdi", "uart", "com"]
    for port, desc in ports:
        desc_lower = desc.lower()
        for kw in esp_keywords:
            if kw in desc_lower:
                print(f"[*] 自动检测到串口: {port} ({desc})")
                return port

    # 如果只有一个 COM 口，直接使用
    if len(ports) == 1:
        port, desc = ports[0]
        print(f"[*] 只有一个串口，自动选择: {port} ({desc})")
        return port

    print("[!] 检测到多个串口，无法自动确定 ESP32 设备:")
    for port, desc in ports:
        print(f"    {port} - {desc}")
    return None


def check_esptool():
    """检查 esptool 是否可用，不可用则尝试安装"""
    try:
        subprocess.run([sys.executable, "-m", "esptool", "--version"],
                       capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("[!] esptool 未安装，正在自动安装...")
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "esptool"],
                           check=True)
            print("[*] esptool 安装成功")
            return True
        except subprocess.CalledProcessError:
            print("[X] esptool 安装失败，请手动安装: pip install esptool")
            return False


def verify_bin_files():
    """检查所有 bin 文件是否存在"""
    missing = []
    for _, rel_path, desc in FLASH_MAP:
        full_path = os.path.join(BUILD_DIR, rel_path)
        if not os.path.isfile(full_path):
            missing.append((rel_path, desc))

    if missing:
        print("[X] 缺少以下固件文件:")
        for path, desc in missing:
            print(f"    build/{path}  ({desc})")
        print("\n请先在 ESP-IDF 环境中运行: idf.py build")
        return False

    # 显示文件大小
    total = 0
    for _, rel_path, _ in FLASH_MAP:
        full_path = os.path.join(BUILD_DIR, rel_path)
        size = os.path.getsize(full_path)
        total += size
        print(f"    {rel_path:<45} {size/1024:>8.1f} KB")
    print(f"    {'总计':<45} {total/1024:>8.1f} KB")
    return True


def flash_firmware(port):
    """烧录固件"""
    cmd = [
        sys.executable, "-m", "esptool",
        "--chip", CHIP,
        "--port", port,
        "--baud", str(BAUD),
        "--before", "default_reset",
        "--after", "hard_reset",
        "write_flash",
        "--flash_mode", "dio",
        "--flash_freq", "80m",
        "--flash_size", "8MB",
    ]

    for offset, rel_path, _ in FLASH_MAP:
        full_path = os.path.join(BUILD_DIR, rel_path)
        cmd.append(offset)
        cmd.append(full_path)

    print(f"\n[*] 开始烧录 (端口: {port}, 波特率: {BAUD})...")
    print(f"[*] 命令: esptool.py --chip {CHIP} --port {port} write_flash ...\n")

    try:
        subprocess.run(cmd, check=True)
        print("\n" + "=" * 50)
        print("  [OK] 烧录成功！设备正在重启...")
        print("=" * 50)
        return True
    except subprocess.CalledProcessError as e:
        print(f"\n[X] 烧录失败: {e}")
        print("\n常见问题排查:")
        print("  1. 检查 USB 线是否连接，设备是否已上电")
        print("  2. 确认串口未被其他程序占用（串口助手、arduino IDE 等）")
        print("  3. 尝试按住 BOOT 键再上电，进入下载模式")
        print("  4. 降低波特率: python flash.py COM3 --baud 115200")
        return False


# ── 入口 ──

def main():
    global BAUD
    parser = argparse.ArgumentParser(
        description="明镜固件烧录工具 (ESP32-C3)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python flash.py                  # 自动检测串口烧录
  python flash.py COM3             # 指定串口
  python flash.py --list           # 列出可用串口
  python flash.py COM3 --baud 115200   # 指定波特率

首次使用:
  pip install esptool pyserial
        """,
    )
    parser.add_argument("port", nargs="?", default=None,
                        help="串口号 (如 COM3)，不指定则自动检测")
    parser.add_argument("--list", action="store_true",
                        help="列出可用串口并退出")
    parser.add_argument("--baud", type=int, default=BAUD,
                        help=f"烧录波特率 (默认: {BAUD})")
    parser.add_argument("-y", "--yes", action="store_true",
                        help="跳过确认，直接烧录")

    args = parser.parse_args()

    # --list 模式
    if args.list:
        ports = list_serial_ports()
        if ports:
            print("可用串口:")
            for port, desc in ports:
                print(f"  {port:<8} {desc}")
        else:
            print("未检测到串口设备")
        return 0

    # 检查 esptool
    if not check_esptool():
        return 1

    # 检查固件文件
    if not verify_bin_files():
        return 1

    # 确定串口
    port = args.port
    if port is None:
        port = detect_esp_port()
        if port is None:
            print("\n[X] 无法自动检测 ESP32 设备，请手动指定串口:")
            print("    python flash.py COM3")
            print("\n可用串口列表:")
            ports = list_serial_ports()
            for p, desc in ports:
                print(f"    {p} - {desc}")
            return 1

    # 确认
    if not args.yes:
        print(f"\n[*] 将在 {port} 上烧录固件")
        resp = input("确认继续? [Y/n] ").strip().lower()
        if resp and resp != "y":
            print("已取消")
            return 0
    else:
        print(f"\n[*] 自动烧录 → {port}")

    # 更新波特率
    BAUD = args.baud

    # 烧录
    success = flash_firmware(port)
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())

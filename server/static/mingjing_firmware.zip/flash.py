"""
明镜固件烧录工具 (ESP32-C3)
============================

用法:
    python flash.py                  # 交互式选串口烧录
    python flash.py COM3             # 指定串口
    python flash.py COM3 -y          # 指定串口，跳过确认

双击 flash.bat 即可使用，无需手动敲命令。
"""

import sys
import os
import subprocess

# ── 烧录配置 ──
CHIP = "esp32c3"
BAUD = 921600

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BUILD_DIR = os.path.join(SCRIPT_DIR, "build")

FLASH_MAP = [
    ("0x0",     "bootloader/bootloader.bin",              "Bootloader"),
    ("0x8000",  "partition_table/partition-table.bin",     "Partition Table"),
    ("0xe000",  "ota_data_initial.bin",                    "OTA Data"),
    ("0x20000", "aidoll_device.bin",                       "Firmware"),
]


def install_deps():
    """安装缺失的依赖"""
    deps = ["esptool", "pyserial"]
    for dep in deps:
        try:
            __import__(dep if dep != "pyserial" else "serial")
        except ImportError:
            print(f"[*] 正在安装 {dep}（首次使用需联网下载，请稍候）...")
            subprocess.run([sys.executable, "-m", "pip", "install", dep],
                           check=True)
            print(f"[*] {dep} 安装完成")
    print()


def list_serial_ports():
    """列出可用串口"""
    import serial.tools.list_ports
    ports = serial.tools.list_ports.comports()
    return [(p.device, p.description) for p in sorted(ports)]


def pick_port():
    """交互式选择串口"""
    ports = list_serial_ports()
    if not ports:
        print("[X] 未检测到任何串口设备")
        print("    请确认 ESP32-C3 已通过 USB 连接并上电")
        return None

    # 只有一个串口 → 直接使用
    if len(ports) == 1:
        port, desc = ports[0]
        print(f"[*] 检测到 1 个串口，自动选择: {port} ({desc})")
        return port

    # 多个串口 → 让用户选
    print("检测到以下串口，请选择 ESP32-C3 对应的端口:\n")
    for i, (port, desc) in enumerate(ports, 1):
        print(f"  [{i}] {port:<8} {desc}")

    print(f"  [0] 退出")
    print()

    while True:
        try:
            choice = input("请输入序号: ").strip()
            if choice == "0":
                return None
            idx = int(choice) - 1
            if 0 <= idx < len(ports):
                return ports[idx][0]
            print("无效序号，请重试")
        except ValueError:
            print("请输入数字")
        except (EOFError, KeyboardInterrupt):
            return None


def verify_bin_files():
    """检查固件文件"""
    missing = []
    for _, rel_path, desc in FLASH_MAP:
        if not os.path.isfile(os.path.join(BUILD_DIR, rel_path)):
            missing.append((rel_path, desc))

    if missing:
        print("[X] 缺少以下固件文件:")
        for path, desc in missing:
            print(f"    build/{path}  ({desc})")
        return False

    print("固件文件:")
    total = 0
    for _, rel_path, _ in FLASH_MAP:
        size = os.path.getsize(os.path.join(BUILD_DIR, rel_path))
        total += size
        print(f"    {rel_path:<45} {size/1024:>8.1f} KB")
    print(f"    {'总计':<45} {total/1024:>8.1f} KB")
    print()
    return True


def flash_firmware(port):
    """烧录"""
    cmd = [
        sys.executable, "-m", "esptool",
        "--chip", CHIP,
        "--port", port,
        "--baud", str(BAUD),
        "--before", "default-reset",
        "--after", "hard-reset",
        "write-flash",
        "--flash-mode", "dio",
        "--flash-freq", "80m",
        "--flash-size", "8MB",
    ]
    for offset, rel_path, _ in FLASH_MAP:
        cmd += [offset, os.path.join(BUILD_DIR, rel_path)]

    print(f"正在烧录 → {port} (波特率: {BAUD})")
    print()

    try:
        subprocess.run(cmd, check=True)
        print()
        print("=" * 50)
        print("  [OK] 烧录成功！设备正在重启...")
        print("=" * 50)
        return True
    except subprocess.CalledProcessError as e:
        print(f"\n[X] 烧录失败: {e}")
        print()
        print("常见问题排查:")
        print("  1. USB 线是否连接，设备是否上电")
        print("  2. 串口是否被其他程序占用")
        print("  3. 试试按住 BOOT 键再上电，进入下载模式")
        return False


def main():
    print()
    print("=" * 50)
    print("  明镜固件烧录工具  —  ESP32-C3")
    print("=" * 50)
    print()

    # 命令行模式
    if len(sys.argv) > 1:
        port = sys.argv[1] if not sys.argv[1].startswith("-") else None
        if not port:
            port = pick_port()
            if not port:
                return 1
        install_deps()
        if not verify_bin_files():
            return 1
        print(f"将在 {port} 上烧录，按 Enter 继续，Ctrl+C 取消...")
        try:
            input()
        except (EOFError, KeyboardInterrupt):
            print("\n已取消")
            return 0
        ok = flash_firmware(port)
    else:
        # 交互模式
        install_deps()
        if not verify_bin_files():
            input("\n按 Enter 退出...")
            return 1
        port = pick_port()
        if not port:
            print("已退出")
            return 0
        print(f"\n将在 {port} 上烧录，按 Enter 继续，Ctrl+C 取消...")
        try:
            input()
        except (EOFError, KeyboardInterrupt):
            print("\n已取消")
            return 0
        ok = flash_firmware(port)

    if ok:
        print("\n首次启动会自动进入 AP 配网模式 (SSID: Aidoll-Config)")
    print()
    input("按 Enter 退出...")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

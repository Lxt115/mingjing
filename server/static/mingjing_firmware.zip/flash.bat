@echo off
chcp 65001 >nul
cd /d "%~dp0"

:: 检测可用的 Python，优先 py 启动器
set PY=python
where py >nul 2>&1 && set PY=py -3

%PY% flash.py
pause

@echo off
cd /d "%~dp0"
python flash.py
pause
